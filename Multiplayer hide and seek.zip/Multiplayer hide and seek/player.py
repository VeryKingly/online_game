import pygame
from pygame.locals import *
pygame.init()

class Player:
    def __init__(self, image, startRect, start_extra_jumps, speed, input):
        self.image = image
        self.rect = startRect
        self.start_extra_jumps = start_extra_jumps
        self.y_momentum = 0
        self.extra_jumps = 0
        self.facing_right = True
        self.air_timer = 0
        self.wall_timer = 0
        self.moving_right = False
        self.moving_left = False
        self.speed = speed
        self.quit = False
        self.input = input

    def update(self, tile_rects, display, scroll):
        self.get_input()
        self.move_player(tile_rects)
        self.draw(display, [self.rect.x - scroll[0], self.rect.y - scroll[1]])
    
    def draw(self, display, pos):
        display.blit(self.image, (pos[0], pos[1]))

    def move_player(self, tile_rects):
        self.player_movement = [0, 0]
        if self.moving_right:
            self.player_movement[0] += self.speed
        if self.moving_left:
            self.player_movement[0] -= self.speed
        self.player_movement[1] += self.y_momentum
        self.y_momentum += 0.4
        if self.y_momentum > 7:
            self.y_momentum = 7

        self.rect, collisions = move(self.rect, self.player_movement, tile_rects)
        if collisions['bottom']: 
            self.y_momentum = 0
            self.air_timer = 0
            self.extra_jumps = self.start_extra_jumps
        if collisions['top']:
            self.y_momentum = 0
        else:
            self.air_timer += 1
        if collisions['left'] and self.input.keys['a'] and self.y_momentum > 0 or collisions['right'] and self.input.keys['d'] and self.y_momentum > 0:
            self.y_momentum = 1
            self.wall_timer = 0
        else:
            self.wall_timer += 1

        if self.input.keys['w'] and self.wall_timer < 14:
            self.jump()

        if self.facing_right and self.moving_left or not self.facing_right and self.moving_right:
            self.facing_right = not self.facing_right
            self.image = pygame.transform.flip(self.image, True, False)

    def jump(self):
        self.y_momentum = -6
        self.extra_jumps -= 1
    
    def get_input(self):
        if self.input.keys['quit']:
            self.quit = True
        if self.input.keys['d']:
            self.moving_right = True
        else:
            self.moving_right = False
        if self.input.keys['a']:
            self.moving_left = True
        else:
            self.moving_left = False
        if self.input.keys['w'] and self.air_timer < 8 or self.input.keys['w'] and self.extra_jumps > -1:
            self.jump()

def collision_test(rect, tiles):
        hit_list = []
        for tile in tiles:
            if rect.colliderect(tile):
                hit_list.append(tile)
        return hit_list

def move(rect, movement, tiles):
    collision_types = {'top': False, 'bottom': False, 'right': False, 'left': False}
    rect.x += movement[0]
    hit_list = collision_test(rect, tiles)
    for tile in hit_list:
        if movement[0] > 0:
            rect.right = tile.left
            collision_types['right'] = True
        elif movement[0] < 0:
            rect.left = tile.right
            collision_types['left'] = True
    rect.y += movement[1]
    hit_list = collision_test(rect, tiles)
    for tile in hit_list:
        if movement[1] > 0:
            rect.bottom = tile.top
            collision_types['bottom'] = True
        elif movement[1] < 0:
            rect.top = tile.bottom
            collision_types['top'] = True
            movement[1] = 0
    return rect, collision_types