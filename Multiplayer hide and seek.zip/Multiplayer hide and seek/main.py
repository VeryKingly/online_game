import pygame, sys
from pygame.locals import *
from network import Network
from input import Input
from player import *
from map import *
pygame.init()
clock = pygame.time.Clock()
 
pygame.display.set_caption('Abyss')
WINDOW_SIZE = (1200, 800)
back_color = (49, 44, 87)
screen = pygame.display.set_mode(WINDOW_SIZE,0,32) # initiate the window
display = pygame.Surface((600, 400))

game_map = load_map('map')

player_image = pygame.image.load('player_animations/idle/idle_0.png').convert_alpha()
tileset_image = pygame.image.load('tileset.png').convert_alpha()
TILE_SIZE = 16

true_scroll = [0,0]

def read_pos(str):
    str = str.split(',')
    return int(str[0]), int(str[1])

def make_pos(tup):
    return str(tup[0]) + ',' + str(tup[1])

input = Input()

n = Network()
start_pos = read_pos(n.get_pos())
p = Player(player_image, pygame.Rect(start_pos[0], start_pos[1], player_image.get_width() - 1, player_image.get_height()), 1, 3, input)
p2 = Player(player_image, pygame.Rect(50, 550, player_image.get_width(), player_image.get_height()), 1, 2, input)

while True:
    display.fill(back_color)

    if pygame.Rect.colliderect(p.rect, p2.rect):
        p.rect.x = start_pos[0]
        p.rect.y = start_pos[1]

    if p.rect.y > 1000:
        p.rect.x = start_pos[0]
        p.rect.y = start_pos[1]
    
    p2_pos = read_pos(n.send(make_pos((p.rect.x, p.rect.y))))
    p2.rect.x = p2_pos[0]
    p2.rect.y = p2_pos[1]
    
    true_scroll[0] += ((p.rect.x - true_scroll[0]) - 153 * 2) / 20
    true_scroll[1] += ((p.rect.y - true_scroll[1]) - 106 * 2) / 20
    scroll = true_scroll.copy()
    scroll[0] = int(scroll[0])
    scroll[1] = int(scroll[1])

    tile_rects = map_stuff(game_map, TILE_SIZE, scroll, display, tileset_image)
    p.update(tile_rects, display, scroll)
    display.blit(p2.image, (p2.rect.x - scroll[0], p2.rect.y - scroll[1]))
    if p.quit:
        pygame.quit()
        sys.exit()

    input.update()

    surf = pygame.transform.scale(display, WINDOW_SIZE)
    screen.blit(surf, (0,0))
    pygame.display.update()
    clock.tick(60)