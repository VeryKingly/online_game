import pygame
from pygame.locals import *

class Input():
    def __init__(self):
        self.keys = {'w': False, 'a': False, 's': False, 'd': False, 'quit': False, 'left_mouse': False}

    def update(self):
        self.keys['w'] = False
        self.keys['left_mouse'] = False

        #Get Input
        for event in pygame.event.get():
            if event.type == QUIT:
                self.keys['quit'] = True
            if event.type == KEYDOWN:
                if event.key == K_a:
                    self.keys['a'] = True
                if event.key == K_d:
                    self.keys['d'] = True
                if event.key == K_w:
                    self.keys['w'] = True
                if event.key == K_s:
                    self.keys['s'] = True    
            if event.type == KEYUP:
                if event.key == K_a:
                    self.keys['a'] = False
                if event.key == K_d:
                    self.keys['d'] = False
                if event.key == K_s:
                    self.keys['s'] = False
            if event.type == MOUSEBUTTONDOWN:
                self.keys['left_mouse'] = True