import pygame

def load_map(path):
    f = open(path + '.txt','r')
    data = f.read()
    f.close()
    data = data.split('\n')
    game_map = []
    for row in data:
        game_map.append(list(row))
    return game_map

def map_stuff(game_map, TILE_SIZE, scroll, display, tileset_image):
    #Get All Tiles From The 2D Array
    tile_rects = []
    y = 0
    for row in game_map:
        x = 0
        for tile in row:
            if tile != '0':
                tile_rects.append(pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))
                display.blit(tileset_image, (x * TILE_SIZE - scroll[0], y * TILE_SIZE - scroll[1]), ((letter_to_number[tile] - 1) * TILE_SIZE, 0, TILE_SIZE, TILE_SIZE))
            x += 1
        y += 1
    return tile_rects

letter_to_number = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9, 'j': 10, 'k': 11,'l': 12,'m': 13,'n': 14,'o': 15,'p': 16, 'q': 17, 'r': 18,'s': 19,'t': 20,'u': 21, 'v': 22,'w': 23,'x': 24, 'y': 25, 'z': 26}
alphabet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']