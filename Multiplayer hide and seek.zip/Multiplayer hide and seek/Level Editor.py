import pygame
from pygame.locals import *
pygame.init()

class button():
    def __init__(self, x, y, width,height, tile, eraser):
        self.tile = tile
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.eraser = eraser

    def draw(self):
        #Call this method to draw the button on the screen
        if not self.eraser:
            screen.blit(tileset_image, (self.x, self.y), (self.tile * TILE_SIZE, 0, TILE_SIZE, TILE_SIZE))
        else:
            screen.blit(air_image, (self.x, self.y))

    def isOver(self, pos):
        #Pos is the mouse position or a tuple of (x,y) coordinates
        if pos[0] > self.x and pos[0] < self.x + self.width:
            if pos[1] > self.y and pos[1] < self.y + self.height:
                return True
        return False

TILE_SIZE = 16
ROW_SIZE = 88
zoom = 1
background_color = (91, 120, 193)
scroll = [0, 0]
scroll[0] = 0
scroll[1] = 0

current_index = 0

player_image = pygame.image.load('player_animations/idle/idle_0.png')
air_image = pygame.image.load('air.png')
tileset_image = pygame.image.load('tileset.png')

letter_to_number = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9, 'j': 10, 'k': 11,'l': 12,'m': 13,'n': 14,'o': 15,'p': 16, 'q': 17, 'r': 18,'s': 19,'t': 20,'u': 21, 'v': 22,'w': 23,'x': 24, 'y': 25, 'z': 26}
alphabet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']

ROW_AMOUNT = 0
def load_map(path):
    global ROW_AMOUNT
    f = open(path + '.txt','r')
    data = f.read()
    f.close()
    data = data.split('\n')
    game_map = []
    ROW_AMOUNT = len(data)
    for row in data:
        game_map.append(list(row))
    return game_map

def reset_map():
    for row in range(0, ROW_AMOUNT - 2):
        for tile in range(0, ROW_SIZE):
            game_map[row][tile] = '0'
    return game_map

game_map = load_map('map')
screen = pygame.display.set_mode((1500, 800))
display = pygame.Surface((screen.get_width(), screen.get_height()))
screen.fill(background_color)
pygame.display.set_caption('Level Editor')
pygame.display.flip()

buttons = []

for i in range(int(tileset_image.get_width() / TILE_SIZE)):
    buttons.append(button(1428 + (i % 3) * 16, (i + 1 - i % 3) * 8, 16, 16, i, False))
buttons.append(button(1428 + (buttons[len(buttons) - 1].tile % 3) * 16 + 16, (buttons[len(buttons) - 1].tile + 1 - buttons[len(buttons) - 1].tile % 3) * 8, 16, 16, buttons[len(buttons) - 1].tile, True))

def get_mouse_rounded(axis):
    mouse_pos = pygame.mouse.get_pos()
    if axis == 'x':
        mouse_axis = mouse_pos[0]
    else:
        mouse_axis = mouse_pos[1]
    mouse_axis -= mouse_axis % (TILE_SIZE * zoom)
    
    return mouse_axis / zoom

def get_map_str():
    game_map_str = str(game_map).replace('[','').replace(']','').replace(',','').replace("'",'').replace(' ','').replace('"','')
    return game_map_str
    
mouse_down = False
running = True
while running:
    display.fill(background_color)
    y = 0
    for row in game_map:
        x = 0
        for tile in row:
            if tile != '0':
                display.blit(tileset_image, (x * TILE_SIZE - scroll[0], y * TILE_SIZE - scroll[1]), ((letter_to_number[tile] - 1) * TILE_SIZE, 0, TILE_SIZE, TILE_SIZE))
            x += 1
        y += 1
    mouse_y = round(get_mouse_rounded('y') / TILE_SIZE)
    mouse_x = round(get_mouse_rounded('x') / TILE_SIZE)
    if(mouse_x < ROW_SIZE):
        pygame.draw.rect(display, (157, 48, 59), pygame.Rect(get_mouse_rounded('x'), get_mouse_rounded('y'), TILE_SIZE, TILE_SIZE), 2)
    for but in buttons:
        but.draw()
        if mouse_down:
            if pygame.mouse.get_pos()[0] < 1408:
                game_map[int(mouse_y + scroll[1] / TILE_SIZE)][int(mouse_x + scroll[0] / TILE_SIZE)] = str(current_index)
            for but in buttons:
                if but.isOver(pygame.mouse.get_pos()):
                    if not but.eraser:
                        current_index = alphabet[but.tile]
                    else: current_index = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == KEYDOWN:
            if event.key == K_p:
                game_map_str = get_map_str()
                game_map_str_final = '\n'.join(game_map_str[i:i + ROW_SIZE] for i in range(0, len(game_map_str), ROW_SIZE))
                with open("map.txt", 'r+') as f:
                    f.truncate(4)
                    f.write(game_map_str_final)
            if event.key == K_BACKSLASH:
                game_map = reset_map()
            if event.key == K_a:
                scroll[0] += -16
            if event.key == K_d:
                scroll[0] += 16
            if event.key == K_w:
                scroll[1] += -16
            if event.key == K_s:
                scroll[1] += 16

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 4 and zoom < 3:
                zoom += 0.25
            elif event.button == 5 and zoom > 1:
                zoom -= 0.25
            elif event.button == 1:
                mouse_down = True
        if event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                mouse_down = False
        

    surf = pygame.transform.scale(display, (int(display.get_width() * zoom), int(display.get_height() * zoom)))
    screen.blit(surf, (0,0))
    pygame.draw.rect(screen, (200, 200, 200), pygame.Rect(1408, 0, 1000, 1000))
    for but in buttons:
        but.draw()
    pygame.display.update()